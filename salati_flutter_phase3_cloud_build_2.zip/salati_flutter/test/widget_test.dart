import 'package:flutter_test/flutter_test.dart';
import 'package:salati/app/salati_app.dart';

void main() {
  testWidgets('يعرض التطبيق عنوان صلاتي وأقسامه التأسيسية', (tester) async {
    await tester.pumpWidget(const SalatiApp());

    expect(find.text('صلاتي'), findsOneWidget);
    expect(find.text('أقسام التطبيق'), findsOneWidget);
    expect(find.text('مواقيت الصلاة'), findsOneWidget);
  });
}
