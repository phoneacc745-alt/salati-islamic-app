import 'package:flutter/material.dart';
import 'app/salati_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SalatiApp());
}
