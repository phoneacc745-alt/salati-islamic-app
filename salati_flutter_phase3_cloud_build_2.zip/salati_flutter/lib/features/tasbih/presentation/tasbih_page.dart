import 'package:flutter/material.dart';

class TasbihPage extends StatefulWidget {
  const TasbihPage({super.key});
  @override
  State<TasbihPage> createState() => _TasbihPageState();
}

class _TasbihPageState extends State<TasbihPage> {
  int _count = 0;
  int _round = 0;
  static const int _target = 33;

  void _increment() {
    setState(() {
      _count++;
      if (_count % _target == 0) _round++;
    });
  }

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('السبحة الإلكترونية')),
    body: Center(child: Padding(padding: const EdgeInsets.all(24), child: Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Text('سُبْحَانَ اللَّهِ • الْحَمْدُ لِلَّهِ • اللَّهُ أَكْبَرُ', textAlign: TextAlign.center, style: TextStyle(fontSize: 19, fontWeight: FontWeight.w600)),
        const SizedBox(height: 28),
        Text('$_count', style: const TextStyle(fontSize: 72, fontWeight: FontWeight.bold)),
        Text('الجولات المكتملة: $_round'),
        const SizedBox(height: 30),
        SizedBox(width: 210, height: 70, child: FilledButton(
          onPressed: _increment,
          child: const Text('اضغط للتسبيح', style: TextStyle(fontSize: 20)),
        )),
        const SizedBox(height: 16),
        OutlinedButton.icon(onPressed: () => setState(() { _count = 0; _round = 0; }), icon: const Icon(Icons.restart_alt), label: const Text('إعادة العداد')),
        const SizedBox(height: 20),
        const Text('العداد يعمل دون اتصال بالإنترنت. لا تُحفظ القراءة بعد إغلاق التطبيق في هذه النسخة.', textAlign: TextAlign.center, style: TextStyle(fontSize: 12, color: Colors.black54)),
      ],
    ))),
  );
}
