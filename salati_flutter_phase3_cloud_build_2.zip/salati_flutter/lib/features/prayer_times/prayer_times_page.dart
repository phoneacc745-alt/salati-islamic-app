import 'package:adhan/adhan.dart';
import 'package:flutter/material.dart';

class PrayerCity {
  const PrayerCity(this.name, this.latitude, this.longitude);
  final String name;
  final double latitude;
  final double longitude;
}

const prayerCities = <PrayerCity>[
  PrayerCity('القاهرة', 30.0444, 31.2357),
  PrayerCity('الإسكندرية', 31.2001, 29.9187),
  PrayerCity('الجيزة', 30.0131, 31.2089),
  PrayerCity('المنصورة', 31.0409, 31.3785),
  PrayerCity('طنطا', 30.7865, 31.0004),
  PrayerCity('أسيوط', 27.1809, 31.1837),
  PrayerCity('الأقصر', 25.6872, 32.6396),
  PrayerCity('أسوان', 24.0889, 32.8998),
  PrayerCity('شرم الشيخ', 27.9158, 34.3299),
  PrayerCity('مكة المكرمة', 21.3891, 39.8579),
  PrayerCity('المدينة المنورة', 24.5247, 39.5692),
];

enum PrayerMethod { egyptian, ummAlQura, muslimWorldLeague }

extension PrayerMethodLabel on PrayerMethod {
  String get label => switch (this) {
    PrayerMethod.egyptian => 'الهيئة المصرية العامة للمساحة',
    PrayerMethod.ummAlQura => 'أم القرى',
    PrayerMethod.muslimWorldLeague => 'رابطة العالم الإسلامي',
  };

  CalculationParameters get parameters => switch (this) {
    PrayerMethod.egyptian => CalculationMethod.egyptian.getParameters(),
    PrayerMethod.ummAlQura => CalculationMethod.ummAlQura.getParameters(),
    PrayerMethod.muslimWorldLeague =>
      CalculationMethod.muslimWorldLeague.getParameters(),
  };
}

class PrayerTimesPage extends StatefulWidget {
  const PrayerTimesPage({super.key});

  @override
  State<PrayerTimesPage> createState() => _PrayerTimesPageState();
}

class _PrayerTimesPageState extends State<PrayerTimesPage> {
  PrayerCity _city = prayerCities.first;
  PrayerMethod _method = PrayerMethod.egyptian;
  Madhab _madhab = Madhab.shafi;
  DateTime _date = DateTime.now();

  PrayerTimes get _times {
    final coordinates = Coordinates(_city.latitude, _city.longitude);
    final params = _method.parameters;
    params.madhab = _madhab;
    return PrayerTimes(coordinates, DateComponents.from(_date), params);
  }

  String _format(DateTime value) {
    final local = value.toLocal();
    final hour = local.hour % 12 == 0 ? 12 : local.hour % 12;
    final minute = local.minute.toString().padLeft(2, '0');
    return '$hour:$minute ${local.hour < 12 ? 'ص' : 'م'}';
  }

  @override
  Widget build(BuildContext context) {
    final times = _times;
    final entries = <(String, DateTime, IconData)>[
      ('الفجر', times.fajr, Icons.nightlight_round),
      ('الشروق', times.sunrise, Icons.wb_twilight),
      ('الظهر', times.dhuhr, Icons.wb_sunny_outlined),
      ('العصر', times.asr, Icons.sunny),
      ('المغرب', times.maghrib, Icons.wb_twilight),
      ('العشاء', times.isha, Icons.nights_stay_outlined),
    ];

    return Scaffold(
      appBar: AppBar(title: const Text('مواقيت الصلاة')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            elevation: 0,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('إعدادات الموقع والحساب',
                      style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<PrayerCity>(
                    value: _city,
                    decoration: const InputDecoration(
                      labelText: 'المدينة',
                      border: OutlineInputBorder(),
                    ),
                    items: prayerCities.map((city) => DropdownMenuItem(
                      value: city, child: Text(city.name),
                    )).toList(),
                    onChanged: (value) {
                      if (value != null) setState(() => _city = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<PrayerMethod>(
                    value: _method,
                    isExpanded: true,
                    decoration: const InputDecoration(
                      labelText: 'طريقة حساب المواقيت',
                      border: OutlineInputBorder(),
                    ),
                    items: PrayerMethod.values.map((method) => DropdownMenuItem(
                      value: method, child: Text(method.label),
                    )).toList(),
                    onChanged: (value) {
                      if (value != null) setState(() => _method = value);
                    },
                  ),
                  const SizedBox(height: 12),
                  DropdownButtonFormField<Madhab>(
                    value: _madhab,
                    decoration: const InputDecoration(
                      labelText: 'طريقة حساب العصر',
                      border: OutlineInputBorder(),
                    ),
                    items: const [
                      DropdownMenuItem(value: Madhab.shafi, child: Text('الشافعي / المالكي / الحنبلي')),
                      DropdownMenuItem(value: Madhab.hanafi, child: Text('الحنفي')),
                    ],
                    onChanged: (value) {
                      if (value != null) setState(() => _madhab = value);
                    },
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 14),
          Row(
            children: [
              const Icon(Icons.calendar_today_outlined, size: 18),
              const SizedBox(width: 8),
              Text('${_date.year}/${_date.month}/${_date.day}',
                  style: const TextStyle(fontWeight: FontWeight.w600)),
              const Spacer(),
              TextButton.icon(
                onPressed: () => setState(() => _date = DateTime.now()),
                icon: const Icon(Icons.today),
                label: const Text('اليوم'),
              ),
            ],
          ),
          ...entries.map((entry) => Card(
            elevation: 0,
            margin: const EdgeInsets.only(bottom: 8),
            child: ListTile(
              leading: Icon(entry.$3, color: Theme.of(context).colorScheme.primary),
              title: Text(entry.$1, style: const TextStyle(fontWeight: FontWeight.w600)),
              trailing: Text(_format(entry.$2),
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.bold)),
            ),
          )),
          const SizedBox(height: 8),
          const Text(
            'تنبيه: هذه مواقيت محسوبة فلكيًا وفق المدينة وطريقة الحساب المختارتين. '
            'يجب مطابقتها مع التقويم الرسمي المحلي قبل اعتمادها للتنبيه أو العبادة.',
            style: TextStyle(fontSize: 12, color: Colors.black54),
          ),
        ],
      ),
    );
  }
}
