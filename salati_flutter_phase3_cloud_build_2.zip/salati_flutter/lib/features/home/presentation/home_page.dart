import 'package:flutter/material.dart';
import '../../prayer_times/prayer_times_page.dart';
import '../../adhkar/presentation/adhkar_page.dart';
import '../../tasbih/presentation/tasbih_page.dart';
import '../../library/presentation/islamic_library_page.dart';
import '../../shubuhat/presentation/shubuhat_page.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('صلاتي', style: TextStyle(fontWeight: FontWeight.bold)),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              color: Theme.of(context).colorScheme.primaryContainer,
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('السلام عليكم',
                    style: TextStyle(fontSize: 23, fontWeight: FontWeight.bold)),
                SizedBox(height: 8),
                Text('رفيقك اليومي للعبادة والمعرفة الإسلامية.'),
              ],
            ),
          ),
          const SizedBox(height: 22),
          const Text('أقسام التطبيق',
              style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          _FeatureTile(
            icon: Icons.access_time,
            title: 'مواقيت الصلاة',
            subtitle: 'حساب المواقيت حسب المدينة وطريقة الحساب',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(
              builder: (_) => const PrayerTimesPage(),
            )),
          ),
          const _FeatureTile(
            icon: Icons.menu_book_outlined,
            title: 'القرآن الكريم',
            subtitle: 'سيُضاف المصحف المعتمد والتلاوات في مرحلة مستقلة',
          ),
          _FeatureTile(
            icon: Icons.wb_twilight,
            title: 'الأذكار',
            subtitle: 'أذكار مختارة مع عدّاد',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const AdhkarPage())),
          ),
          _FeatureTile(
            icon: Icons.radio_button_checked,
            title: 'السبحة',
            subtitle: 'عداد تسبيح يعمل دون إنترنت',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const TasbihPage())),
          ),
          const _FeatureTile(
            icon: Icons.explore_outlined,
            title: 'القبلة',
            subtitle: 'قيد التطوير',
          ),
          _FeatureTile(
            icon: Icons.menu_book,
            title: 'المكتبة الإسلامية',
            subtitle: 'فهرس الكتب المقترحة ومصادرها',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const IslamicLibraryPage())),
          ),
          _FeatureTile(
            icon: Icons.forum_outlined,
            title: 'الرد على الشبهات',
            subtitle: 'موضوعات مرتبة بمنهج بحث موثق',
            onTap: () => Navigator.of(context).push(MaterialPageRoute(builder: (_) => const ShubuhatPage())),
          ),
          const SizedBox(height: 12),
          Text(
            'الإصدار التطويري 0.3 — بعض الأقسام أصبحت تفاعلية، ' 
            'ولا تزال أقسام أخرى قيد البناء والمراجعة.',
            style: Theme.of(context).textTheme.bodySmall,
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

class _FeatureTile extends StatelessWidget {
  const _FeatureTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 0,
      margin: const EdgeInsets.only(bottom: 9),
      child: ListTile(
        leading: Icon(icon, color: Theme.of(context).colorScheme.primary),
        title: Text(title, style: const TextStyle(fontWeight: FontWeight.w600)),
        subtitle: Text(subtitle),
        trailing: const Icon(Icons.chevron_left),
        onTap: onTap ?? () => ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('هذا القسم سيُفعّل في مرحلة لاحقة.')),
        ),
      ),
    );
  }
}
