import 'package:flutter/material.dart';

class ShubuhatPage extends StatelessWidget {
  const ShubuhatPage({super.key});
  static const topics = <(String, String)>[
    ('وجود الله تعالى', 'مدخل إلى الأدلة العقلية والفطرية على وجود الخالق.'),
    ('النبوة والوحي', 'بحث دلائل صدق النبوة وإمكان الوحي.'),
    ('القرآن الكريم', 'دراسة تاريخ النص القرآني وجوانب إعجازه.'),
    ('السنة النبوية', 'مصادر السنة ومناهج المحدثين في نقد الروايات.'),
    ('القدر والحرية الإنسانية', 'تحرير العلاقة بين علم الله ومشيئته ومسؤولية الإنسان.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('الرد على الشبهات')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('منهج البحث', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('نعرض السؤال أولًا بإنصاف، ثم نحرر محل النزاع، ونفحص الأدلة والمصادر، ونميز بين المعلومة الثابتة والاستنتاج وموضع الخلاف.'),
      const SizedBox(height: 16),
      ...topics.map((topic) => Card(elevation: 0, child: ListTile(
        leading: const Icon(Icons.question_answer_outlined),
        title: Text(topic.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(topic.$2),
        trailing: const Icon(Icons.chevron_left),
        onTap: () => showDialog<void>(context: context, builder: (context) => AlertDialog(
          title: Text(topic.$1),
          content: const Text('سيُبنى هذا الملف على عرض الشبهة بصيغتها الدقيقة، ثم الجواب الموثق من المصادر الأصلية، مع ذكر الاعتراضات المهمة دون تهويل أو اختزال.'),
          actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('حسنًا'))],
        )),
      ))),
      const SizedBox(height: 8),
      const Text('هذا القسم إطار تنظيمي أولي، وليس فتوى أو موسوعة مكتملة. ستُراجع المواد علميًا قبل اعتمادها.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );
}
