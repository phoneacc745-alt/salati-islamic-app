import 'package:flutter/material.dart';

class IslamicLibraryPage extends StatelessWidget {
  const IslamicLibraryPage({super.key});
  static const books = <(String, String)>[
    ('الأربعون النووية', 'أحاديث جامعة في أصول الدين والأخلاق والعبادات.'),
    ('رياض الصالحين', 'أبواب في الآداب والرقائق والعبادات والأخلاق.'),
    ('حصن المسلم', 'مجموعة من الأذكار والأدعية المأثورة.'),
    ('تفسير السعدي', 'تفسير ميسر لمعاني القرآن الكريم.'),
    ('الأدب المفرد', 'أحاديث وآثار في مكارم الأخلاق والآداب.'),
  ];

  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: const Text('المكتبة الإسلامية')),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('رفّ المعرفة', style: TextStyle(fontSize: 21, fontWeight: FontWeight.bold)),
      const SizedBox(height: 8),
      const Text('قائمة أولية بالكتب المقترحة لإضافتها بنصوص محققة ومراجعة.'),
      const SizedBox(height: 14),
      ...books.map((book) => Card(elevation: 0, child: ListTile(
        leading: const Icon(Icons.menu_book_outlined),
        title: Text(book.$1, style: const TextStyle(fontWeight: FontWeight.bold)),
        subtitle: Text(book.$2),
        trailing: const Icon(Icons.schedule),
        onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('سيُتاح نص الكتاب بعد استكمال المراجعة والتوثيق.'))),
      ))),
      const SizedBox(height: 8),
      const Text('لن ندرج نصوصًا دينية غير موثقة؛ وستُضاف بيانات المصدر والتحقيق لكل كتاب قبل نشره داخل التطبيق.', style: TextStyle(fontSize: 12, color: Colors.black54)),
    ]),
  );
}
