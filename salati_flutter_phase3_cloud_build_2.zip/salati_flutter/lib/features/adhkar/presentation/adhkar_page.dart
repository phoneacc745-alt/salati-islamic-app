import 'package:flutter/material.dart';

class AdhkarPage extends StatefulWidget {
  const AdhkarPage({super.key});

  @override
  State<AdhkarPage> createState() => _AdhkarPageState();
}

class _AdhkarPageState extends State<AdhkarPage> {
  final List<_Dhikr> _items = const [
    _Dhikr('سُبْحَانَ اللَّهِ', 'تنزيه الله تعالى عن كل نقص.', 33),
    _Dhikr('الْحَمْدُ لِلَّهِ', 'الثناء على الله تعالى مع المحبة والتعظيم.', 33),
    _Dhikr('اللَّهُ أَكْبَرُ', 'الله أعظم من كل شيء.', 34),
    _Dhikr('أَسْتَغْفِرُ اللَّهَ', 'طلب المغفرة من الله تعالى.', 100),
  ];
  int _selected = 0;
  int _count = 0;

  @override
  Widget build(BuildContext context) {
    final item = _items[_selected];
    final remaining = (item.target - _count).clamp(0, item.target);
    return Scaffold(
      appBar: AppBar(title: const Text('الأذكار والتسبيح')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        const Text('اختر الذكر', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
        const SizedBox(height: 10),
        DropdownButtonFormField<int>(
          value: _selected,
          isExpanded: true,
          decoration: const InputDecoration(border: OutlineInputBorder(), labelText: 'الذكر'),
          items: List.generate(_items.length, (i) => DropdownMenuItem(value: i, child: Text(_items[i].text))),
          onChanged: (v) => setState(() { _selected = v ?? 0; _count = 0; }),
        ),
        const SizedBox(height: 28),
        Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(22), child: Column(children: [
          Text(item.text, textAlign: TextAlign.center, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          Text(item.meaning, textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodyMedium),
          const SizedBox(height: 24),
          Text('$_count', style: const TextStyle(fontSize: 52, fontWeight: FontWeight.bold)),
          Text('المستهدف: ${item.target}  •  المتبقي: $remaining'),
          const SizedBox(height: 22),
          SizedBox(width: 190, height: 56, child: FilledButton.icon(
            onPressed: () => setState(() { if (_count < item.target) _count++; }),
            icon: const Icon(Icons.touch_app), label: const Text('تسبيح'),
          )),
          TextButton.icon(onPressed: () => setState(() => _count = 0), icon: const Icon(Icons.refresh), label: const Text('تصفير العداد')),
        ]))),
        const SizedBox(height: 12),
        const Text('تنبيه: هذه أذكار مختارة للعدّ، ولا تمثل حصرًا لجميع أذكار الصباح والمساء أو أحكام أعدادها.', style: TextStyle(fontSize: 12, color: Colors.black54)),
      ]),
    );
  }
}

class _Dhikr {
  const _Dhikr(this.text, this.meaning, this.target);
  final String text;
  final String meaning;
  final int target;
}
