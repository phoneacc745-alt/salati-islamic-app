import 'package:flutter/material.dart';
import '../features/home/presentation/home_page.dart';

class SalatiApp extends StatelessWidget {
  const SalatiApp({super.key});

  @override
  Widget build(BuildContext context) {
    const seed = Color(0xFF176B55);
    return MaterialApp(
      title: 'صلاتي – المساعد الإسلامي',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: seed),
        scaffoldBackgroundColor: const Color(0xFFF7F8F5),
      ),
      locale: const Locale('ar'),
      home: const Directionality(
        textDirection: TextDirection.rtl,
        child: HomePage(),
      ),
    );
  }
}
